package com.javainfinite;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;


@RestController
public class AppController {
	
	@RequestMapping(value="/docker2")
	public String display() {
		RestTemplate restTemplate = new RestTemplate();
		String s = restTemplate.getForObject("http://helloworld:8080/docker1", String.class);
		return s;
	}
	
	@RequestMapping(value="/docker2/test")
	public String display1() {
		return "Yes working";
	}

}
