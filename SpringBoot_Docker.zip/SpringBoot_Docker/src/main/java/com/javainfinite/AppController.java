package com.javainfinite;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class AppController {
	
	@RequestMapping(value="/docker1")
	public String display() {
		return "Hello World - From SpringBoot_Docker";
	}

}
